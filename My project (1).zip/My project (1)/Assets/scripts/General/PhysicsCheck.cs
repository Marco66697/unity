using UnityEngine;

public class PhysicsCheck : MonoBehaviour
{
    public Vector2 bottomOffset;
    public float checkRaduis;
    public LayerMask groundLayer;
    public bool isGround;

    private void Update()
    {
        Check();
    }

    public void Check()
    {
        // 檢測地面並更新 isGround
        isGround = Physics2D.OverlapCircle((Vector2)transform.position + bottomOffset, checkRaduis, groundLayer) != null;

        // 輸出偵測結果
        //Debug.Log("isGround: " + isGround);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere((Vector2)transform.position + bottomOffset, checkRaduis);
    }
}
