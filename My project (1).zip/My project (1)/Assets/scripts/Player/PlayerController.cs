using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
public class PlayerController : MonoBehaviour
{
   public PlayerInputControl inputControl;
  
   private Rigidbody2D rb;
   private PhysicsCheck physicsCheck;
   private PlayerAnimation playerAnimation;

   public Vector2 inputDirection;
   [Header("基本參數")]

   public float speed ;

   public float jumpForce;

   public float hurtForce;

   public Vector2 originalOffset;

   public Vector2 originalSize;

   [Header("物理材質")]
   public PhysicsMaterial2D normal;
   public PhysicsMaterial2D wall;

   [Header("狀態")]
   public bool isCroach;

   public bool  isHurt;

   public bool  isDead;

   public bool isAttack;

   private void Awake()
   { 
     rb=GetComponent<Rigidbody2D>();
     physicsCheck = GetComponent<PhysicsCheck>();
     inputControl = new PlayerInputControl();
     //Collider = GetComponent<CapsuleCollider2D>();
     playerAnimation = GetComponent<PlayerAnimation>();

     //originalOffset = coll.Offset;
     //originalSize = coll.size;

     inputControl = new PlayerInputControl();

     inputControl.GamePlay.Jump.started+= Jump;


     inputControl.GamePlay.Attack.started+=PlayerAttack;
   }

   private void OnEnable()
   {
    inputControl.Enable();
   }

   private void OnDisable()
   {
    inputControl.Disable();
   }

   private void Update()
   {
    inputDirection = inputControl.GamePlay.Move.ReadValue<Vector2>();

    CheckStake();
   }

   private void FixedUpdate()
   {  
      if(!isHurt && !isAttack)
      Move();
   }

   public void Move()
   {  
      
      rb.linearVelocity = new Vector2(inputDirection.x*speed*Time.deltaTime,rb.linearVelocity.y);
      int faceDir = (int)transform.localScale.x;
      if(inputDirection.x>0)
        faceDir=3;
      if(inputDirection.x<0)
        faceDir=-3;  
      transform.localScale = new Vector3(faceDir,3,3);
   }
   private void Jump(InputAction.CallbackContext obj )
   {
    //Debug.Log("Jump");
    if(physicsCheck.isGround)
    rb.AddForce(transform.up*jumpForce, ForceMode2D.Impulse);
   }
   private void PlayerAttack(InputAction.CallbackContext obj)
   {
      playerAnimation.PlayAttack();
      isAttack = true;
      
   }

   public void GetHurt(Transform attacker)
   {
      isHurt = true;
      rb.linearVelocity = Vector2.zero;
      Vector2 dir = new Vector2((transform.position.x - attacker.position.x),0).normalized;

      rb.AddForce(dir * hurtForce, ForceMode2D.Impulse);
   }
   public void PlayerDead()
   {
      isDead = true;
      inputControl.GamePlay.Disable();
   }

   private void CheckStake()
   {
      //Collider.sharedMaterial = physicsCheck.isGround ? normal : wall;
   }
}
